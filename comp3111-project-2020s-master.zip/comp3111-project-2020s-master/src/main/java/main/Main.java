package main;

/**
 * Main class to start the application.
 */
public class Main {
    public static void main(String args[]) {
        comp3111.coursescraper.MyApplication.run(args);
    }
}