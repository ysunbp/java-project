package comp3111.coursescraper;

import java.util.Locale;
import java.time.format.DateTimeFormatter;
/**
 * This class help with the logical check in task 2 checkboxes.
 * @author SUN Yushi
 *
 */
public class Checkboxes{
	/**
	 * This function checks if the course has lab or tuto
	 * @param c this is the course to be checked for having lab tuto
	 * @return boolean expression indicate whether it has lab tuto. 
	 */
    public static boolean hasLabTuto(Course c) {
        int NUM_SECTION = c.getNumSections();
        for (int i = 0; i < NUM_SECTION; i++) {
            String code = c.getSection(i).getCode();
            // System.out.println(code.substring(0,2));
            if (code.substring(0, 1).equals("T") || code.substring(0, 2).equals("LA")) {
                // System.out.println("enter");
                return true;
            } else {
                continue;
            }
        }
        return false;
    }
    
    
    /**
     * This function check if a certain section has AM slots
     * @param s is the section to be checked
     * @return the boolean indicating whether it has AM slots
     */
    public static boolean hasAM(Section s) {
        for (int j = 0; j < s.getNumSlots(); j++) {
            if (s.getSlot(j).getStart().format(DateTimeFormatter.ofPattern("a", Locale.US)).equals("AM")) {
            	return true;}
            }
    	return false;
            	
    }
    
    /**
     * This function check if a certain section has PM slots
     * @param s is the section to be checked
     * @return the boolean indicating whether it has PM slots
     */
    public static boolean hasPM(Section s) {
    	
        for (int j = 0; j < s.getNumSlots(); j++) {
            if (s.getSlot(j).getEnd().format(DateTimeFormatter.ofPattern("a", Locale.US))
                	.equals("PM")) {
                return true;}
            }
    	return false;
    }
    
    /**
     * This function check if a certain section has slots on certain day
     * @param s is the section to be checked
     * @param box is the checkbox provided in UI
     * @return boolean indicating whether the section has slots on certain days
     */
    public static boolean hasDay(Section s, String box) {
    	
        for (int j = 0; j < s.getNumSlots(); j++) {
            if (Slot.DAYS[s.getSlot(j).getDay()].equals(box)) {
                return true;
                }
            }
    	return false;
    }
    
    /**
	 * This function checks if has no exclusion
	 * @param c this is the course to be checked for having no exclusions
	 * @return boolean expression indicate whether it has no exclusions
	 */
    public static boolean hasNoExclusion(Course c) {
        if (c.getExclusion().contentEquals("null")) {
            return true;
        }
        return false;
    }

    /**
	 * This function checks if it is CCC
	 * @param c this is the course to be checked for being CCC
	 * @return boolean expression indicate whether it is CCC
	 */
    public static boolean hasCCC(Course c) {
        if (c.getAttribute().contains("4Y")) {
            return true;
        }
        return false;
    }
}