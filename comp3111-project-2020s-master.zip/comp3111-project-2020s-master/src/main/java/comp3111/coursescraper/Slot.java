package comp3111.coursescraper;

import java.util.Map;
import java.util.HashMap;
import java.time.Duration;
import java.time.LocalTime;
import java.util.Locale;
import java.time.format.DateTimeFormatter;

/**
 * <p>
 * The class that represents a slot.
 * </p>
 * <p>
 * A section may have zero, one, two, or three slots. A slot contains both
 * information about time and venue. The time of a slot shall be represented by
 * one day the week and a consecutive time from 9:00AM to 10:00PM. Any slot with
 * a time that does not follow this rule is considered invalid. A time slot
 * contains two days should be considered as two slots.
 * </p>
 * 
 * @author kevinw and LYu Hanfang
 */
public class Slot {
	private int day;
	private LocalTime start;
	private LocalTime end;
	private String venue;
	public static final String DAYS[] = { "Mo", "Tu", "We", "Th", "Fr", "Sa" };
	public static final Map<String, Integer> DAYS_MAP = new HashMap<String, Integer>();
	static {
		for (int i = 0; i < DAYS.length; i++)
			DAYS_MAP.put(DAYS[i], i);
	}

	/**
	 * Clone the slot.
	 */
	@Override
	public Slot clone() {
		Slot s = new Slot();
		s.day = this.day;
		s.start = this.start;
		s.end = this.end;
		s.venue = this.venue;
		return s;
	}

	/**
	 * Print the information of the slot.
	 */
	public String toString() {
		return "Date & Time: " + DAYS[day] + " " + start.toString() + " - " + end.toString() + " Venue: " + venue;
	}

	/**
	 * 
	 * @return the start hour of the slot.
	 */
	public int getStartHour() {
		return start.getHour();
	}

	/**
	 * 
	 * @return the start minute of the slot.
	 */
	public int getStartMinute() {
		return start.getMinute();
	}

	/**
	 * 
	 * @return the end hour of the slot.
	 */
	public int getEndHour() {
		return end.getHour();
	}

	/**
	 * 
	 * @return the end minute of the slot.
	 */
	public int getEndMinute() {
		return end.getMinute();
	}

	/**
	 * @return the start time of this slot.
	 */
	public LocalTime getStart() {
		return start;
	}

	/**
	 * @param start the start time(format: "hh:mma") to set
	 */
	public void setStart(String start) {
		this.start = LocalTime.parse(start, DateTimeFormatter.ofPattern("hh:mma", Locale.US));
	}

	/**
	 * @return the end time of this slot
	 */
	public LocalTime getEnd() {
		return end;
	}

	/**
	 * @param end the end time(format: "hh:mma") to set
	 */
	public void setEnd(String end) {
		this.end = LocalTime.parse(end, DateTimeFormatter.ofPattern("hh:mma", Locale.US));
	}

	/**
	 * 
	 * @return the total minutes of the slot.
	 */
	public long getLastMinute() {
		return Duration.between(start, end).toMinutes();
	}

	/**
	 * @return the venue of this slot.
	 */
	public String getVenue() {
		return venue;
	}

	/**
	 * @param venue the venue to set
	 */
	public void setVenue(String venue) {
		this.venue = venue;
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @param day the day to set
	 */
	public void setDay(int day) {
		this.day = day;
	}

	/**
	 * Check if the slot is at a specific time.
	 * 
	 * @param DAY  The day of the specific time.
	 * @param hour The hour of the specific time.
	 * @param min  The minute of the specific time.
	 * @return true, if the slot is at the specific time; false otherwise.
	 */
	public boolean atSpecificTime(String DAY, int hour, int min) {
		int Day = DAYS_MAP.get(DAY);

		boolean atDay = (this.day == Day);
		boolean startBefore = (this.getStartHour() < hour)
				|| (this.getStartHour() == hour && this.getStartMinute() <= min);
		boolean endAfter = (this.getEndHour() > hour) || (this.getEndHour() == hour && this.getEndMinute() >= min);

		return (atDay && startBefore && endAfter);
	}

}
