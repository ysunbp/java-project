package comp3111.coursescraper;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.text.Font;
import javafx.geometry.Insets;

/**
 * This class contains some helper functions for task 4 Timetable.
 * 
 * @author LYU Hanfang
 */
public class Timetable {

    /**
     * A list of <b>different</b> colors.
     */
    protected static List<Color> colors = new ArrayList<Color>();
    /**
     * Index that indicates which color is going to used in the next seciton.
     */
    private static int colorIndex = 0;

    /**
     * This function create a specific number of <i>different</i> colors and store
     * them in the variable Timetable.colors for later use.
     * 
     * @param num The number of different color to be created.
     */
    public static void randomColors(int num) {
        colors.clear();
        colorIndex = 0;
        for (int i = 0; i < num; i++) {
            Random r = new Random();
            Color c = Color.rgb(r.nextInt(256), r.nextInt(256), r.nextInt(256), 0.5);
            while (colors.contains(c)) {
                c = Color.rgb(r.nextInt(256), r.nextInt(256), r.nextInt(256), 0.5);
            }
            colors.add(c);
        }
    }

    /**
     * This function create UI labels of all the slots in a section.
     * 
     * @param courseCode The String that is the course code of the section.
     * @param sec        The section whose slots are going to be shown.
     * @return A list of labels that contains all the labels of slots in the
     *         section.
     */
    public static List<Label> createTimeSlots(String courseCode, Section sec) {
        List<Label> timeSlots = new ArrayList<Label>();
        for (int i = 0; i < sec.getNumSlots(); ++i) {
            Label slot = new Label(courseCode + "\n" + sec.getCode());
            int day = sec.getSlot(i).getDay();
            int startHour = sec.getSlot(i).getStartHour();
            int startMin = sec.getSlot(i).getStartMinute();
            double start = 40 + 20 * (startHour - 9) + startMin * 1.0 / 3.0;
            double height = sec.getSlot(i).getLastMinute() * 1.0 / 3.0;

            Font f = new Font((height / 3 > 12) ? 12 : height / 3);
            slot.setFont(f);
            Color color = colors.get(colorIndex % colors.size());
            if (color.getRed() + color.getBlue() + color.getGreen() < 1.5) {
                slot.setStyle("-fx-text-fill: #fff !important;");
            } else {
                slot.setStyle("-fx-text-fill: #000 !important;");
            }

            slot.setBackground(new Background(new BackgroundFill(color, CornerRadii.EMPTY, Insets.EMPTY)));
            slot.setLayoutX(100 * (day + 1));
            slot.setLayoutY(start);
            slot.setMinWidth(100.0);
            slot.setMaxWidth(100.0);
            slot.setMinHeight(height);
            slot.setMaxHeight(height);
            slot.setPadding(new Insets(1, 1, 1, 5));
            slot.setOpacity(0.9);

            timeSlots.add(slot);
        }
        colorIndex = (++colorIndex) % colors.size();
        return timeSlots;
    }
}