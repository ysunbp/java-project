package comp3111.coursescraper;

/**
 * <p>
 * The class that represents a section.
 * </p>
 * <p>
 * There is at least one section in a course. A course can have multiple
 * sections, identified by a unique section-ID. A section code is a unique
 * identifier within a course. Combining the course code and section code, there
 * will be a unique section in that semester. A code starts with <b>L</b>
 * followed by any characters except <b>A</b> is lecture. A section code starts
 * with <b>T</b> is a tutorial section. A section code starts with <b>LA</b> is
 * a lab section. Any section code does not follow these three rules can be
 * ignored.
 * </p>
 * 
 * @author LYU Hanfang
 */
public class Section {
    private static final int DEFAULT_MAX_SLOT = 3;
    private static final int DEFAULT_MAX_INSTRUCTOR = 10;

    private int sectionID;
    private String sectionCode;

    private Instructor[] instructors;
    private int numInstructors;

    private Slot[] slots;
    private int numSlots;

    /**
     * Create instructors and slots and set them to null, and set the number of the
     * to 0.
     */
    public Section() {
        instructors = new Instructor[DEFAULT_MAX_INSTRUCTOR];
        for (int i = 0; i < DEFAULT_MAX_INSTRUCTOR; i++)
            instructors[i] = null;
        numSlots = 0;
        slots = new Slot[DEFAULT_MAX_SLOT];
        for (int i = 0; i < DEFAULT_MAX_SLOT; i++)
            slots[i] = null;
        numSlots = 0;
    }

    /**
     * Print the information of the section.
     */
    public String toString() {
        String printSection = sectionCode + " (" + sectionID + ")" + "\n";
        if (instructors[0] != null) {
            printSection += "\tInstructor: \n";
            for (int i = 0; i < getNumInstructors(); i++) {
                printSection += "\t\t" + instructors[i] + "\n";
            }
        }
        for (int j = 0; j < numSlots; j++) {
            Slot s = slots[j];
            printSection += "\tSlot " + (j + 1) + " - " + s + "\n";
        }
        return printSection;
    }

    /**
     * Clone the section.
     */
    public Section clone() {
        Section s = new Section();
        s.setID(this.sectionID);
        s.setCode(this.sectionCode);
        for (Instructor instructor : this.instructors) {
            s.addInstructor(instructor);
        }
        for (Slot slot : this.slots) {
            s.addSlot(slot);
        }
        return s;
    }

    /**
     * 
     * @return the id of the section.
     */
    public int getID() {
        return sectionID;
    }

    /**
     * 
     * @param id the id to set.
     */
    public void setID(int id) {
        sectionID = id;
    }

    /**
     * 
     * @return the code of the section
     */
    public String getCode() {
        return sectionCode;
    }

    /**
     * 
     * @param code the code to set
     */
    public void setCode(String code) {
        sectionCode = code;
    }

    /**
     * 
     * @return An array of all the instructors in the section.
     */
    public Instructor[] getAllInstructors() {
        return instructors;
    }

    /**
     * 
     * @param name The name of the instructor to find.
     * @return The instructor if the instructor teaches the section; null otherwise.
     */
    public Instructor findInstructorByName(String name) {
        for (int i = 0; i < numInstructors; ++i) {
            if (instructors[i].getName().equals(name)) {
                return instructors[i];
            }
        }
        return null;
    }

    /**
     * 
     * @param ins the instructor to add.
     */
    public void addInstructor(Instructor ins) {
        if (ins != null) {
            if (numInstructors >= DEFAULT_MAX_INSTRUCTOR) {
                return;
            }
            instructors[numInstructors++] = ins.clone();
        }
    }

    /**
     * 
     * @return the number of the instructor in this section.
     */
    public int getNumInstructors() {
        return numInstructors;
    }

    /**
     * Get the i-th slot of the section.
     * 
     * @param i The index of the slot to get
     * @return The i-th slot in the section, if i is in valid range; null, otherwise
     */
    public Slot getSlot(int i) {
        if (i >= 0 && i < numSlots)
            return slots[i];
        return null;
    }

    /**
     * 
     * @param s The slot to add.
     */
    public void addSlot(Slot s) {
        if (s != null) {
            if (numSlots >= DEFAULT_MAX_SLOT) {
                return;
            }
            slots[numSlots++] = s.clone();
        }
    }

    /**
     * @return the number of slots in the section.
     */
    public int getNumSlots() {
        return numSlots;
    }
}