package comp3111.coursescraper;

/**
 * Instructor is a class for instructors.
 * 
 * @author LYU Hanfang
 */ 
public class Instructor {
    
    /**
     * A string of the instructor's name.
     */
    private String name;

    /**
     * A Instructor is constructed with Instructor.name initialized.
     * 
     * @param name A String that is passed to the constructor to initialize the name of the instructor.
     */
    public Instructor(String name) {
        this.name = name;
    }

    /**
     * Properly print the instructor.
     */
    public String toString() {
        return name;
    }

    /**
     * Clone the instructor.
     */
    public Instructor clone() {
        Instructor newIns = new Instructor(this.name);
        return newIns;
    }

    /**
     * Get the name of the instructor.
     * 
     * @return A string, the instructor's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name of the instructor.
     * 
     * @param name The instructor's name to be set to this.name.
     */
    public void setName(String name) {
        this.name = name;
    }

}