package comp3111.coursescraper;

/**
 * <p>
 * The class that represents a course.
 * </p>
 * <p>
 * A course can be identified by a unique course code. COMP3111 and COMP3111H
 * are two different courses although they are colisted.
 * </p>
 * 
 * @author kevinw, LYU Hanfang and SUN Yushi
 */
public class Course {

	/**
	 * The maximum number of slots in a course: {@value}
	 */
	private static final int DEFAULT_MAX_SLOT = 100;

	/**
	 * A course can be identified by a unique course code.
	 */
	private String code;
	private String title;

	private String description;
	private String exclusion;
	private String attribute;

	private Section[] sections;
	private int numSections;

	/**
	 * Create sections and set all sections to null, and set numSections to 0.
	 */
	public Course() {
		sections = new Section[DEFAULT_MAX_SLOT];
		for (int i = 0; i < DEFAULT_MAX_SLOT; i++)
			sections[i] = null;
		numSections = 0;
	}

	/**
	 * Print the information of the course.
	 */
	public String toString() {
		String printCourse = title + "\n";
		for (int i = 0; i < numSections; i++) {
			Section t = getSection(i);
			printCourse += "Section " + (i + 1) + ": " + t;
		}
		return printCourse;
	}

	/**
	 * @return the course code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	private void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the course title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
		String[] splitedTitle = title.split(" ");
		if (splitedTitle.length > 2) {
			String code = splitedTitle[0] + splitedTitle[1];
			setCode(code);
		}
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the exclusion
	 */
	public String getExclusion() {
		return exclusion;
	}

	/**
	 * @param exclusion the exclusion to set
	 */
	public void setExclusion(String exclusion) {
		this.exclusion = exclusion;
	}

	/**
	 * Get the i-th section of the course.
	 * 
	 * @param i The index of the section to get
	 * @return sections[i], if i is in valid range; null, otherwise
	 */
	public Section getSection(int i) {
		if (i >= 0 && i < numSections) {
			return sections[i];
		}
		return null;
	}

	/**
	 * Get the section of the spectific id in the course.
	 * 
	 * @param id id of the seciton to get.
	 * @return The section to get or null if the id is invalid.
	 */
	public Section getSectionByID(int id) {
		for (Section section : sections) {
			if (section != null) {
				if (section.getID() == id) {
					return section;
				}
			}
		}
		return null;
	}

	/**
	 * Get the section of the spectific code in the course.
	 * 
	 * @param code code of the seciton to get.
	 * @return The section to get or null if the code is invalid.
	 */
	public Section getSectionByCode(String code) {
		for (Section section : sections) {
			if (section != null) {
				if (section.getCode() == code) {
					return section;
				}
			}
		}
		return null;
	}

	/**
	 * Add a section to {@link #sections}.
	 * 
	 * @param s The section to add.
	 */
	public void addSection(Section s) {
		if (s != null) {
			if (numSections >= DEFAULT_MAX_SLOT) {
				System.err.println("Too many sections in a course!");
				return;
			}
			sections[numSections++] = s.clone();
		}
	}

	/**
	 * 
	 * @return The number of sections in the course.
	 */
	public int getNumSections() {
		return numSections;
	}

	/**
	 * 
	 * @return The num of instructors in the course.
	 */
	public int getNumInstructors() {
		int num = 0;
		for (int i = 0; i < getAllInstructors().length; i++) {
			if (getAllInstructors()[i] != null) {
				++num;
			}
		}
		return num;
	}

	/**
	 * A helper function that checks if the course contains a certain instructor to
	 * prevent duplication.
	 * 
	 * @param name        The name of the instructor.
	 * @param instructors Instructors in the course.
	 * @return true, if the course contains the instructor; false if not.
	 */
	private boolean containsIns(String name, Instructor[] instructors) {
		for (int i = 0; i < instructors.length; i++) {
			if (instructors[i] != null) {
				if (instructors[i].getName() == name) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 
	 * @return An array of Instrucotrs in the course.
	 */
	public Instructor[] getAllInstructors() {
		Instructor[] instructors = new Instructor[10 * DEFAULT_MAX_SLOT];
		for (int i = 0; i < instructors.length; i++) {
			instructors[i] = null;
		}

		int index = 0;
		for (int i = 0; i < numSections; i++) {
			for (int j = 0; j < sections[i].getNumInstructors(); j++) {
				if (!containsIns(sections[i].getAllInstructors()[j].getName(), instructors)) {
					instructors[index++] = sections[i].getAllInstructors()[j].clone();
				}
			}
		}
		return instructors;
	}

	/**
	 * 
	 * @return The number of slots in the course.
	 */
	public int getNumSlots() {
		int numSlots = 0;
		for (Section sec : sections) {
			if (sec != null) {
				numSlots += sec.getNumSlots();
			}
		}
		return numSlots;
	}

	/**
	 * Get the i-th slot of the course.
	 * 
	 * @param i The index of the slot to get
	 * @return The i-th slot in the course, if i is in valid range; null, otherwise
	 */
	public Slot getSlot(int i) {
		if (i >= 0 && i < this.getNumSlots()) {
			for (int j = 0; j < numSections; ++j) {
				if (sections[j].getNumSlots() > i) {
					return sections[j].getSlot(i);
				} else {
					i -= sections[j].getNumSlots();
				}
			}
		}
		return null;
	}

	/**
	 * Set the {@link #attribute} of the course.
	 * 
	 * @param attribute The sttribute to set.
	 */
	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	/**
	 * 
	 * @return The {@link #attribute} of the course.
	 */
	public String getAttribute() {
		return attribute;
	}

	/**
	 * Clone the course
	 * @return a course with sections
	 */
	public Course clone() {
		Course c = new Course();
		c.setTitle(this.title);
		c.setDescription(this.description);
		c.setExclusion(this.exclusion);
		c.setAttribute(this.attribute);
		for (int i = 0; i < this.getNumSections(); i++) {
			c.addSection(this.getSection(i));
		}
		return c;
	}
	
	/**
	 * This function clone a course without sections
	 * @return a course without sections
	*/
	public Course cloneWithoutSection() {
		Course c = new Course();
		c.setTitle(this.title);
		c.setDescription(this.description);
		c.setExclusion(this.exclusion);
		c.setAttribute(this.attribute);
		return c;
	}
}
