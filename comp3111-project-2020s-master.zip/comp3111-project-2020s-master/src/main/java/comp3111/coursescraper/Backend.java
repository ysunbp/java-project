package comp3111.coursescraper;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;

/**
 * This class deals with the information of the scrapped courses.
 * 
 * @author LYU Hanfang, SUN Yushi and ZENG Junyan
 */
public class Backend {

    /**
     * A scraper to scrap the course
     */
    private static Scraper scraper = new Scraper();

    /**
     * A list of courses that is searched in task 1.
     */
    public static List<Course> scrappedCourses;

    /**
     * Total number of sections searched in task 1.
     */
    protected static int NUMBER_OF_SECTIONS;
    /**
     * Total number of courses searched in task 1, including all courses that has at
     * least one lecture section, or a lab section, or a tutorial section.
     */
    protected static int NUMBER_OF_COURSES;
    /**
     * Instructors who has teaching assignment this term but does not need to teach
     * at Tu 3:10pm (task 1).
     */
    protected static List<String> INSTRUCTOR_NAME;

    /**
     * Function that scraps the searched courses and store them in the public
     * variable Backend.scrappedCourses. 
     * Assign null to Backend.scrappedCourses if 404 happens.
     * 
     * @param url     The base url of the searched courses
     * @param term    A term consists of four numbers
     * @param subject Refers to the four-letter code prefix of a course code, e.g.
     *                COMP, ACCT, LANG, SHSS, UROP.
     */
    public static void scrapCourses(String url, String term, String subject) {
        try {
            scrappedCourses = null;
            scrappedCourses = scraper.scrape(url, term, subject);
        } catch (Exception e) {
            scrappedCourses = null;
        }
    }

    /**
     * This function shows all the information about sections, slots and instructors
     * of a list of courses
     * 
     * @param v The list of courses.
     * @return A string of the courses' information that is required to printed in
     *         the console.
     */
    public static String showCourses(List<Course> v) {
        NUMBER_OF_COURSES = 0;
        NUMBER_OF_SECTIONS = 0;
        String consoleText = "";

        if (v == null) { // 404 not found
            consoleText = "404 page not found >.<\n" + "Please check the internet or the input.\n";
        } else {
            NUMBER_OF_COURSES = v.size();
            for (Course c : v) {
                if (c.getNumSections() == 0) {
                    --NUMBER_OF_COURSES;
                } else {
                    NUMBER_OF_SECTIONS += c.getNumSections();
                    consoleText += c + "\n";
                }
                // consoleText += c + "\n";
            }
        }

        return consoleText;
    }

    /**
     * This function is a helper function that returns a list of instructors name of
     * the courses.
     * 
     * @param v The list of courses to get all the instructors' name.
     * @return A list of string which contains all the instructors' name in it.
     */
    protected static List<String> getAllInstructorNames(List<Course> v) {
        List<String> names = new ArrayList<String>();
        if (v != null) {
            for (Course c : v) {
                Instructor[] instructors = c.getAllInstructors();
                for (int j = 0; j < c.getNumInstructors(); j++) {
                    String name = instructors[j].getName();
                    if (!name.equals("TBA") && !names.contains(name)) {
                        names.add(name);
                    }
                }
            }
        }
        return names;
    }

    /**
     * This function is a helper function of task 1 that remove all the instructors
     * in INSTRUCTOR_NAME that are not available at Tu 3:10pm
     * 
     * @param v The list of courses related.
     */
    private static void removeInstructorNotAvailable(List<Course> v) {
        for (Course c : v) {
            for (int i = 0; i < c.getNumSections(); i++) {
                for (int j = 0; j < c.getSection(i).getNumSlots(); j++) {
                    if (c.getSection(i).getSlot(j).atSpecificTime("Tu", 15, 10)) {
                        for (int k = 0; k < c.getSection(i).getNumInstructors(); k++) {
                            INSTRUCTOR_NAME.remove(c.getSection(i).getAllInstructors()[k].getName());
                        }
                    }
                }
            }
        }
    }

    /**
     * This function shows the number of sections and courses in the search and all
     * the instructors who has teaching assignment this term but does not need to
     * teach at Tu 3:10pm: -INSTRUCTOR_NAME1, -INSTRUCTOR_NAME2,
     * -INSTRUCTOR_NAME3,...
     * 
     * @param v The list of courses related
     * @return A list of string that contains all the information of the search
     *         required in task 1
     */
    public static String showInfo(List<Course> v) {
        String total = "";
        INSTRUCTOR_NAME = new ArrayList<String>();

        if (v != null) {
            total = "Total Number of difference sections in this search: " + NUMBER_OF_SECTIONS + "\n";
            total += "Total Number of Course in this search: " + NUMBER_OF_COURSES + "\n";

            INSTRUCTOR_NAME = getAllInstructorNames(v);
            removeInstructorNotAvailable(v);
            INSTRUCTOR_NAME.sort(Comparator.comparing(String::toString));

            total += "Instructors who has teaching assignment this term but does not need to teach at Tu 3:10pm: ";
            for (int i = 0; i < INSTRUCTOR_NAME.size(); i++) {
                total += "-" + INSTRUCTOR_NAME.get(i) + " ";
            }
            total += "\n";
        }

        return total;
    }

    /**
     * A link between Controller.java and Scraper.java
     * 
     * @param url     The url used to scrape course code(input in search tab).
     * @param term    The term info used to scrape course code(input in search tab).
     * @param subject The subject info used to scrape course code(input in search
     *                tab), can be arbitrary since we scrape all the course code in
     *                this function.
     * @return call the scrapeCode() function in scraper
     */
    public static List<String> scrapCoursesCode(String url, String term, String subject) {
        return scraper.scrapeCode(url, term, subject);
    }

    /**
     * Get all instructors name in the scrapped courses.
     * 
     * @return The private function getAllInstructorNames(scrappedCourses)
     */
    public static List<String> getAllInstructors() {
        return getAllInstructorNames(scrappedCourses);
    }

}