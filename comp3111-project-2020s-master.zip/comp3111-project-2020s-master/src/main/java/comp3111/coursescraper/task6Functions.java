package comp3111.coursescraper;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.gargoylesoftware.htmlunit.StringWebResponse;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HTMLParser;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

import comp3111.coursescraper.Controller.enrolledCourseItem;

public class task6Functions {
	public task6Functions() {
		client = new WebClient();
		client.getOptions().setCssEnabled(false);
		client.getOptions().setJavaScriptEnabled(false);
	}
	private static WebClient client = new WebClient();
	
	/**
	 * the reformat storage of information of the html file
	 */
	public static class task6Item{
		public String CourseName;
		public String section;
		public String instructor;
		public float SectionGrade;
		public float InstructorGrade;
		public task6Item(
				String CourseName,
				String section,
				String instructor,
				float SectionGrade,
				float InstructorGrade) {
			this.CourseName = CourseName;
			this.section = section;
			this.instructor = instructor;
			this.SectionGrade = SectionGrade;
			this.InstructorGrade = InstructorGrade;
		}
		
	}
	/**determine the type of each row in the table 
	 * four types: -1 useless; 0 info about courseCode; 1 info about sections; 2 info about instructors
	 */
	private static int getTypeOfLine(HtmlElement item) {
		//four types: -1 useless; 0 courseCode; 1 sections; 2 instructors
		List<?> temp = (List<?>)item.getByXPath(".//td");
		
		if(temp==null)return -1;
		if(temp.isEmpty())return -1;
		
		String str0 = ((HtmlElement)temp.get(0)).getTextContent().replace("\u00a0"," ");
		String str1 = ((HtmlElement)temp.get(1)).getTextContent().replace("\u00a0"," ");
		String str2 = ((HtmlElement)temp.get(2)).getTextContent().replace("\u00a0"," ");
		
		if(((HtmlElement)temp.get(0)).getAttribute("colspan").equals("3"))return 0;
		if(str0.equals(" ") && str2.equals(" "))return 1;
		if(str0.equals(" ") && str1.equals(" "))return 2;
		return -1;
	}
	/**for different cases handle the data reading
	 * @param item: the html section to be read
	 * @param Case: the case of the html code
	 */
	private static String getInfoOfLine(HtmlElement item,int Case) {
		switch(Case) {
		case 0://return course code
			List<?> temp_0 = (List<?>) item.getByXPath(".//td[@colspan='3']");
			if(!temp_0.isEmpty()) {
				String Code = ((HtmlElement)temp_0.get(0)).getTextContent().replace("\u00a0"," ").strip();
				return Code;
			}
			System.out.print("getInfoOfLine case error: case 0");
			break;
		case 1://return section code
			List<?> temp_1 = (List<?>) item.getByXPath(".//td");
			if(!(temp_1.size()<3)) {
				String section = ((HtmlElement)temp_1.get(1)).getTextContent().replace("\u00a0"," ").strip();
				return section;
			}
			System.out.print("getInfoOfLine case error: case 1");
			break;
		case 2://return instructor name
			List<?> temp_2 = (List<?>) item.getByXPath(".//td");
			if(!(temp_2.size()<3)){
				String instructor = ((HtmlElement)temp_2.get(2)).getTextContent().replace("\u00a0"," ").strip();
				return instructor;
			}
			System.out.print("getInfoOfLine case error: case 2");
			break;
		default://useless
			break;
		}
		return "";
	}
	
	/**if a line store grade, use this function to get the float grade
	 * @param typeOfLine: 
	 * 	typeOfLine = 1 :sectionGrade; typeOfLine = 2 :instructorGrade
	 */
	private static float getGrade(HtmlElement item,int typeOfLine) {
		// (todo)check the format of output 
		//typeOfLine = 1 :sectionGrade
		//typeOfLine = 2 :instructorGrade
		List<?> temp = (List<?>) item.getByXPath(".//td");
		if((temp.size()<8)){
			System.out.print("getGrade error");
			return 0;
		}
		String sectionGrade = ((HtmlElement)temp.get(3)).getTextContent().replace("\u00a0"," ").strip().split("[(]")[0];
		String instructorGrade = ((HtmlElement)temp.get(4)).getTextContent().replace("\u00a0"," ").strip().split("[(]")[0];
		switch(typeOfLine) {
		case 1:
			if(sectionGrade.equals("-") && instructorGrade.equals("-")) return 0;
			if(sectionGrade.equals("-"))sectionGrade = instructorGrade;
			float sectionGradeFloat = Float.parseFloat(sectionGrade);
			return sectionGradeFloat;
		case 2:
			if(sectionGrade.equals("-") && instructorGrade.equals("-")) return 0;
			if(instructorGrade.equals("-"))instructorGrade = sectionGrade;
			float instructorGradeFloat = Float.parseFloat(instructorGrade);
			return instructorGradeFloat;
		default:
			System.out.print("getGrade case error");
		}
		return 0;
	}
	
	/**the result of the decoding, store courses' grades and instructors' grades
	 */
	private static List<task6Item> result = new ArrayList<task6Item>();
	
	/**
	 *  @param url: the input url
	 *  @param testing: whether use the html file as input
	 * caller function of the previous helper functions, generate the result
	 */
	public static void search(String url,boolean testing) {//generate the list of result
		result.clear();
		try {
			
			String str = "";
			HtmlPage page = null;
			if(testing) {
				try {//testing
					InputStream f = new FileInputStream("src\\main\\resources\\sfq.html");
					int size = f.available();
					for(int i = 0;i<size;i++) {
						str+=(char)(f.read());
					}
					f.close();
				    
				}catch(Exception e) {
					System.out.println("search0 error: "+e);
				}
				URL n_url = new URL(url);
				StringWebResponse responce = new StringWebResponse(str, n_url);
				page = HTMLParser.parseHtml(responce,client.getCurrentWindow());
			}
			else {
				page = client.getPage(url);
			}
			/**/
			
			List<?> items = (List<?>) page.getByXPath("//table[@border='1']/tbody");
			items.remove(0);
			if(items==null||items.isEmpty())return;
			for(int i = 0; i < items.size(); i++) {
				
				HtmlElement htmlItem = (HtmlElement) items.get(i);
				List<?> temp = (List<?>) htmlItem.getByXPath(".//tr");
				
				
				String CourseCode = "";
				String section = "";
				String Instructor = "";
				float SectionGrade = 0;
				
				for(Object item:temp) {
					int typeOfLine = getTypeOfLine((HtmlElement)item);
					switch(typeOfLine) {
					case 0:
						CourseCode = getInfoOfLine((HtmlElement)item,typeOfLine);
						break;
					case 1:
						section = getInfoOfLine((HtmlElement)item,typeOfLine);
						SectionGrade = getGrade((HtmlElement)item ,typeOfLine);
						break;
					case 2:
						Instructor = getInfoOfLine((HtmlElement)item,typeOfLine);
						float InstructorGrade = getGrade((HtmlElement)item,typeOfLine); 
						result.add(new task6Item(CourseCode,section,Instructor,SectionGrade,InstructorGrade));
						break;
					case -1:
						break;
					default:
						System.out.println("task6Functions case error");
					}	
				}	
			}
		} 
		catch (Exception e) {
			System.out.println("search1 error: "+e);
		}
	}

	/**store the interim result for further calculation of average grade
	 */
	private static class construction{
		public String CourseName;
		public int times;
		public float TotalGrade;
		public construction(String CourseName,int times,float TotalGrade) {
			this.CourseName = CourseName;
			this.times = times;
			this.TotalGrade = TotalGrade;
		}
	}
	private static List<construction> courses = new ArrayList<construction>();
	/**helper function to get the grade of a certain section
	 * @param CourseName: name of the course
	 * @param section: the section code of the course (i.e. L1,LA1)
	 */
	private static float SearchList(String CourseName,String section) {
		for(task6Item searchItem:result) {
			if(searchItem.CourseName.equals(CourseName) &&
					searchItem.section.equals(section)) {
				return searchItem.SectionGrade;
			}
		}
		return -1;//-1 for not exist
	}
	
	/**
	 * return the average of the total grades
	 * */
	private static float SearchInstructor(String name) {//return the average of the total grades
		float grade = 0;
		int times = 0;
		for(task6Item searchItem:result) {
			if(searchItem.instructor.equals(name)) {
				times++;
				grade+=searchItem.InstructorGrade;
			}
		}
		if(times==0)return -1;//-1 for not exist
		return grade/times;
	}
	/**
	 * the output list contain a certain course
	 * */
	private static int contains(String name) {//the output list contain a certain course
		if(courses.size()==0||courses==null)return -1;
		for(int i = 0;i<courses.size();i++) {
			if(courses.get(i).CourseName.equals(name))return i;
		}
		return -1;
	}
	/**
	 * @param enrolledCources : the list of all enrolled course
	 * @return outputString: the console output
	 * */
	public static String searchEnrollCourse(List<enrolledCourseItem> enrolledCources) {
		if(enrolledCources==null||enrolledCources.isEmpty())return "";
		courses.clear();
		String outputString = "Find SFQ with my enrolled courses:\n";
		for(enrolledCourseItem item:enrolledCources) {
			String title = item.course.getTitle();
			String CourseName = title.substring(0, title.indexOf("-")).strip();
			String section = item.section.getCode().strip();
			
			float grade = SearchList(CourseName,section);
			if(grade==-1)continue;//can't find the grade of the course section
			int i = contains(CourseName);
			if(i!=-1) {//the courses array doesn't have course named courseName 
				courses.get(i).times++;
				courses.get(i).TotalGrade+=grade;
			}
			else {
				courses.add(new construction(CourseName,1,grade));
			}
		}
		for(construction item :courses) {
			outputString+="\tCourse: "+item.CourseName+" Grade: "+String.valueOf(item.TotalGrade/item.times)+'\n';
		}
		return outputString;
	}

	/**
	 * @param instructorLise : the list of all instructors
	 * @return outputString: the console output
	 * */
	public static String searchInstructors(List<String> instructorLise) {
		if(instructorLise==null||instructorLise.isEmpty())return "";
		String OutputString  = "Instructors' average SFQ:\n";
		for(String instructor:instructorLise) {
			float grade = SearchInstructor(instructor);
			if(grade==-1)continue;
			OutputString+="\t instructor: "+instructor+" grade: "+String.valueOf(grade)+'\n';
		}
		
		return OutputString;
	}
}
