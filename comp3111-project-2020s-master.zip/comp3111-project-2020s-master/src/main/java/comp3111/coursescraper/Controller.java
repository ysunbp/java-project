package comp3111.coursescraper;

import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.layout.AnchorPane;

/**
 * The controller class used in the program. Handle the UI and all the tasks in
 * this class.
 * 
 * @author LYU Hanfang, SUN Yushi and ZENG Junyan
 *
 */
public class Controller {

    @FXML
    private Tab tabMain;

    @FXML
    private TextField textfieldTerm;

    @FXML
    private TextField textfieldSubject;

    @FXML
    private Button buttonSearch;

    @FXML
    private TextField textfieldURL;

    @FXML
    private Tab tabStatistic;

    @FXML
    private ComboBox<?> comboboxTimeSlot;

    @FXML
    private Tab tabFilter;

    @FXML
    private Tab tabTimetable;

    @FXML
    private Tab tabAllSubject;

    @FXML
    private ProgressBar progressbar;

    @FXML
    private TextArea textAreaConsole;

    @FXML
    private CheckBox ambox, pmbox, monbox, tuebox, wedbox, Thubox, Fribox, Satbox, cccbox, noexbox, labtutobox;

    @FXML
    private Button all;

    @FXML
    private Button allsubsearch;

    private int count = 0;
    private List<Course> prefilteredCourses = new ArrayList<Course>();
    private List<Course> filteredCourses = new ArrayList<Course>();
    private List<String> CoursesCode = new ArrayList<String>();
    private List<Course> allSubjectCourses = new ArrayList<Course>();

    public Controller() {
        task6Init();
    }

    // Task 1
    private String backendString = "";

    /**
     * A private function that helps to print scrapped course's information in the
     * console.
     * 
     * @param v A List of scrapped courses, can be null.
     */
    private void printCourses(List<Course> v) {
        backendString = Backend.showCourses(v) + "\n" + Backend.showInfo(v);
        textAreaConsole.setText(backendString);
        settingArray(true, false);
    }

    /**
     * This function will be called after the search button in main tab is clicked:
     * Scrap the courses searched, show backend information, update filter
     * information, and enable the sfq buttons.
     * 
     */
    @FXML
    void search() {
        Backend.scrapCourses(textfieldURL.getText(), textfieldTerm.getText(), textfieldSubject.getText());

        filter();

        printCourses(Backend.scrappedCourses);
        buttonSfqEnrollCourse.setDisable(false);
        buttonInstructorSfq.setDisable(false);
    }

    /**
     * This function will be called when entering the Backend Tab.
     * The console will show the current information of all the searched/filtered courses.
     */
    @FXML
    public void backend() {
        textAreaConsole.setText(backendString);
    }
    // end of task 1

    // task 2 filter
    /**
     * Task 2 filter function. Called when the 'filter' tab or any of the checkboxes
     * is clicked. Update the filtered information in the console, and store the
     * filtered result into List filteredCourses.
     */
    @FXML
    public void filter() {
        if (Backend.scrappedCourses == null)
            return;
        if (Backend.scrappedCourses.isEmpty())
            return;
        prefilteredCourses.clear();
        filteredCourses.clear();
        for (Course c : Backend.scrappedCourses) {
            if ((Checkboxes.hasLabTuto(c) || !labtutobox.isSelected())
                    && (Checkboxes.hasNoExclusion(c) || !noexbox.isSelected())
                    && (Checkboxes.hasCCC(c) || !cccbox.isSelected())) {
                prefilteredCourses.add(c.clone());
            }
        }
        if (!prefilteredCourses.isEmpty()) {
            for (Course c : prefilteredCourses) {
                Course cp = c.cloneWithoutSection();
                for (int i = 0; i < c.getNumSections(); i++) {
                    Section s = c.getSection(i);
                    if ((Checkboxes.hasAM(s) || !ambox.isSelected()) && (Checkboxes.hasPM(s) || !pmbox.isSelected())
                            && (Checkboxes.hasDay(s, "Mo") || !monbox.isSelected())
                            && (Checkboxes.hasDay(s, "Tu") || !tuebox.isSelected())
                            && (Checkboxes.hasDay(s, "We") || !wedbox.isSelected())
                            && (Checkboxes.hasDay(s, "Th") || !Thubox.isSelected())
                            && (Checkboxes.hasDay(s, "Fr") || !Fribox.isSelected())
                            && (Checkboxes.hasDay(s, "Sa") || !Satbox.isSelected())) {
                        cp.addSection(s);
                    }
                }
                if (cp.getNumSections() > 0) {
                    filteredCourses.add(cp);
                }
            }
        }
        printCourses(filteredCourses);
        settingArray(false, false);// update for task 3

    }

    /**
     * A helper function in task 2. Handle the Select All functionality in the UI.
     * Will be called when user click on Select All button.
     */
    @FXML
    public void selectall() {
        if (all.getText().equals("Select All")) {
            all.setText("De-select All");
            ambox.setSelected(true);
            pmbox.setSelected(true);
            monbox.setSelected(true);
            tuebox.setSelected(true);
            wedbox.setSelected(true);
            Thubox.setSelected(true);
            Fribox.setSelected(true);
            Satbox.setSelected(true);
            cccbox.setSelected(true);
            noexbox.setSelected(true);
            labtutobox.setSelected(true);

        } else {
            all.setText("Select All");
            ambox.setSelected(false);
            pmbox.setSelected(false);
            monbox.setSelected(false);
            tuebox.setSelected(false);
            wedbox.setSelected(false);
            Thubox.setSelected(false);
            Fribox.setSelected(false);
            Satbox.setSelected(false);
            cccbox.setSelected(false);
            noexbox.setSelected(false);
            labtutobox.setSelected(false);
        }
        filter();
    }
    // task 2 ends

    // task 5 all subject search
    /**
     * All subject search function in task 5 Called when user click on the all
     * subject search button. Display the total number of code prefix when is
     * clicked once. Display the total number of courses scrapped when is clicked
     * more than one times. Update the scrappedCourses, filteredCourses list and set
     * the array in task 3.
     */
    @FXML
    public void allSubjectSearch() {
        buttonSfqEnrollCourse.setDisable(false);
        buttonInstructorSfq.setDisable(false);
        count++;
        if (count == 1) {
            CoursesCode = Backend.scrapCoursesCode(textfieldURL.getText(), textfieldTerm.getText(),
                    textfieldSubject.getText());
            if (CoursesCode == null) {
                textAreaConsole.setText("404 page not found >.<\n" + "Please check the internet or the input.\n");
                count = 0;
                return;
            }
            textAreaConsole
                    .setText("Total Number of Categories/Code Prefix: " + Integer.toString(CoursesCode.size()) + "\n");
        } else {
            Task<Void> task = new Task<Void>() {
                @Override
                protected Void call() {
                    allSubjectCourses.clear();
                    int i = 0;
                    for (String CourseCode : CoursesCode) {
                        Backend.scrapCourses(textfieldURL.getText(), textfieldTerm.getText(), CourseCode);
                        allSubjectCourses.addAll(Backend.scrappedCourses);
                        Backend.scrappedCourses.clear();
                        System.out.println(CourseCode + " is done");
                        i++;
                        updateProgress(i, CoursesCode.size());

                    }
                    return null;
                }
            };
            progressbar.progressProperty().bind(task.progressProperty());
            Thread thread = new Thread(task);
            thread.setDaemon(true);
            thread.start();
            task.setOnSucceeded((WorkerStateEvent t) -> {
                Backend.scrappedCourses.clear();
                Backend.scrappedCourses.addAll(allSubjectCourses);
                filter();
                textAreaConsole.clear();
                textAreaConsole.setText(
                        "Total Number of Categories/Code Prefix: " + Integer.toString(CoursesCode.size()) + "\n");
                textAreaConsole.setText(textAreaConsole.getText() + "Total Number of Courses fetched: "
                        + Integer.toString(allSubjectCourses.size()) + "\n");
            });
            count = 0;
        }
    }

    // task 3
    @FXML
    private Tab tabList;
    @FXML
    private TableView<Task3Item> ListTable;
    @FXML
    private TableColumn<Task3Item, Integer> CodeColumn;
    @FXML
    private TableColumn<Task3Item, String> SectionColumn;
    @FXML
    private TableColumn<Task3Item, String> NameColumn;
    @FXML
    private TableColumn<Task3Item, String> InstrustorColumn;
    @FXML
    private TableColumn<Task3Item, Boolean> EnrollColumn;

    private ObservableList<Task3Item> ListArray = FXCollections.observableArrayList();
    private List<enrolledCourseItem> enrolledCources = new ArrayList<>();

    /**
     * the object to show to store the information of the list
     */
    static class Task3Item {
        public int CourseCode = 0;
        public String LectureSection = null;
        public String CourseName = null;
        public String instructors = null;
        public CheckBox enrolled = new CheckBox();
        public Course course = null;
        public Section section = null;

        public Task3Item(int CourseCode, String LectureSection, String CourseName, String instructors, Boolean enrolled,
                Course course, Section section) {
            this.CourseCode = CourseCode;
            this.LectureSection = LectureSection;
            this.CourseName = CourseName;
            this.instructors = instructors;
            this.enrolled.setSelected(enrolled);

            this.course = course;
            this.section = section;
        }

        public ReadOnlyObjectWrapper<Integer> CourseCodeProperty() {
            return new ReadOnlyObjectWrapper<Integer>(CourseCode);
        }

        public ReadOnlyObjectWrapper<String> LectureSectionProperty() {
            return new ReadOnlyObjectWrapper<String>(LectureSection);
        }

        public ReadOnlyObjectWrapper<String> CourseNameProperty() {
            return new ReadOnlyObjectWrapper<String>(CourseName);
        }

        public ReadOnlyObjectWrapper<String> instructorsProperty() {
            return new ReadOnlyObjectWrapper<String>(instructors);
        }

    }

    static class enrolledCourseItem {
        int id = 0;
        Course course = null;
        Section section = null;

        enrolledCourseItem(int i, Course c, Section s) {
            id = i;
            course = c;
            section = s;
        }
    }

    @FXML
    private void initialize() {
        ListTable.setEditable(true);
        EnrollColumn.setEditable(true);

        CodeColumn.setCellValueFactory(cellData -> cellData.getValue().CourseCodeProperty());
        SectionColumn.setCellValueFactory(cellData -> cellData.getValue().LectureSectionProperty());
        NameColumn.setCellValueFactory(cellData -> cellData.getValue().CourseNameProperty());
        InstrustorColumn.setCellValueFactory(cellData -> cellData.getValue().instructorsProperty());

        EnrollColumn.setEditable(true);
        EnrollColumn.setCellFactory(column -> new CheckBoxTableCell<>());
        EnrollColumn.setCellValueFactory(cellData -> {
            Task3Item item = cellData.getValue();
            BooleanProperty property = new SimpleBooleanProperty();
            property.setValue(item.enrolled.selectedProperty().getValue());
            property.addListener((observable, oldValue, newValue) -> {
                item.enrolled.setSelected(!item.enrolled.selectedProperty().getValue());
                ClickEvent(item);
            });
            return property;
        });
    }

    /**
     * @param initialize:         whether the array has been initialized, if not run
     *                            initialize() before setting the array
     * @param prevListIsFiltered: the storage of the state of usage of previous list
     */
    static private boolean initialize = true;
    static private boolean prevListIsFiltered = false;

    /**
     * @param search: whether the list has just been searched but not filtered
     * @param prev:   the list used in the previous setting, used in the update of
     *                ClickEvent()
     */
    private void settingArray(boolean search, boolean prev) {
        if (initialize) {
            ListTable.setItems(ListArray);
            initialize();
            initialize = false;
        }

        ListArray.clear();
        List<Course> orilist = filteredCourses;
        if (!prev) {
            if (search) {
                orilist = Backend.scrappedCourses;
            }
            prevListIsFiltered = !search;
        } else {
            if (!prevListIsFiltered) {
                orilist = Backend.scrappedCourses;
            }
        }
        if (orilist != null) {
            for (Course C : orilist) {
                String title = C.getTitle();
                String Code = title.substring(0, title.indexOf("-"));
                title = title.substring(title.indexOf("-") + 1);
                String CourseName = new String(title.substring(0, title.length() - 10));
                // System.out.printf("%s\t%s\n",Code,Name);
                int sectionSize = C.getNumSections();
                for (int i = 0; i < sectionSize; i++) {
                    Section section_i = C.getSection(i);
                    String Instruc = "";
                    for (int m = 0; m < section_i.getNumInstructors(); m++) {
                        Instruc += section_i.getAllInstructors()[m] + "\n";
                    }
                    Boolean enrolled = false;
                    // (todo)write the array in the proper way
                    if (find(section_i.getID()))
                        enrolled = true;

                    ListArray.add(new Task3Item(section_i.getID(), Code + section_i.getCode(), CourseName, Instruc,
                            enrolled, C, section_i));
                }
            }
        }
    }

    private boolean find(int id) {
        return findID(id) != -1;
    }

    /**
     * @param the section id using the section id to find the index of section in
     *            the whole list
     */
    private int findID(int id) {
        for (int i = 0; i < enrolledCources.size(); i++) {
            if (enrolledCources.get(i).section.getID() == id)
                return i;
        }
        return -1;
    }

    /**
     * @param item the item in the observable list maps to the certain checkbox
     */
    public void ClickEvent(Task3Item item) {
        if (item == null)
            return;
        int id = findID(item.section.getID());
        if (id != -1) {
            enrolledCources.remove(findID(item.section.getID()));
        } else {
            enrolledCources.add(new enrolledCourseItem(item.section.getID(), item.course, item.section));
        }

        printEnrolledCourse();
        settingArray(false, true);
    }

    /**
     * print the enrolled course
     */
    private void printEnrolledCourse() {
        String outputText = "The following sections are enrolled:\n";
        for (enrolledCourseItem C : enrolledCources) {
            String title = C.course.getTitle();
            title = title.substring(0, title.indexOf("-"));
            outputText += title + C.section.toString();
        }
        textAreaConsole.setText(outputText);
    }
    // end of task 3

    // task 4
    /**
     * The function showTimetable() was called after entering the Timetable tab:
     * Show sections enrolled in the List tab in the Timetable. Different sections
     * are in different color.
     * 
     */
    @FXML
    void showTimetable() {
        if (enrolledCources.size() != 0) {
            printEnrolledCourse();
        }
        AnchorPane ap = (AnchorPane) tabTimetable.getContent();
        AnchorPane slots = (AnchorPane) ap.getChildren().get(0);
        slots.getChildren().clear();

        Timetable.randomColors(enrolledCources.size());
        for (int i = 0; i < enrolledCources.size(); i++) {
            int id = enrolledCources.get(i).id;
            Course c = enrolledCources.get(i).course;
            if (c != null) {
                slots.getChildren().addAll(Timetable.createTimeSlots(c.getCode(), c.getSectionByID(id)));

            }
        }
    }
    // end of task 4

    private static boolean iniTask6 = true;

    private void task6Init() {
        if (!iniTask6)
            return;
        iniTask6 = false;
        buttonSfqEnrollCourse.setDisable(true);
        buttonInstructorSfq.setDisable(true);
        buttonSfqEnrollCourse.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                findSfqEnrollCourse();
            }
        });
        buttonInstructorSfq.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                findInstructorSfq();
            }
        });
    }

    @FXML
    private TextField textfieldSfqUrl = new TextField();

    @FXML
    private Button buttonSfqEnrollCourse = new Button();

    @FXML
    private Button buttonInstructorSfq = new Button();

    /**
     * using the Backend.getAllInstructors() to get the grade of all instructors
     */
    @FXML
    void findInstructorSfq() {
        task6Functions.search(textfieldSfqUrl.getText(), false);
        String str = task6Functions.searchInstructors(Backend.getAllInstructors());
        textAreaConsole.setText(str);

    }

    /**
     * find the grades of enrolled course
     */
    @FXML
    void findSfqEnrollCourse() {

        task6Functions.search(textfieldSfqUrl.getText(), false);
        String str = task6Functions.searchEnrollCourse(enrolledCources);
        textAreaConsole.setText(str);
    }

    // end of task6
}
