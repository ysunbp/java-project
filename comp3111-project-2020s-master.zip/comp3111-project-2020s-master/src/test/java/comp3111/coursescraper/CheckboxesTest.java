package comp3111.coursescraper;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


public class CheckboxesTest{
	Course c = new Course();
    String description = "Discrete mathematics needed for the study of computer science";
    String Exclusion = "COMP 2711, MATH 2343";

    Section sec = new Section();
    Slot slot = new Slot();
    Instructor ins = new Instructor("Arya");
    
    Course ct = new Course();
	Section st = new Section();
	Course cm = new Course();
	Section sm = new Section();
	Slot ssm = new Slot();
    
	@Before
	public void setUp() throws Exception {
		c.setTitle("COMP 2711H - Honors Design and Analysis of Algorithms");
        c.setDescription(description);
        c.setExclusion(Exclusion);
        c.setAttribute("attribute");
        
        slot.setDay(1);
        slot.setStart("09:00AM");
        slot.setEnd("10:30AM");
        slot.setVenue("TBA");
        sec.addInstructor(ins);
        sec.addSlot(slot);
        sec.setCode("T1");
        sec.setID(1889);
        sec.addSlot(slot);
        c.addSection(sec);
        
		st.setCode("P5");
		ct.addSection(st);
		
		ssm.setDay(1);
        ssm.setStart("02:00PM");
        ssm.setEnd("02:30PM");
        ssm.setVenue("TBA");
        sm.addInstructor(ins);
        sm.addSlot(ssm);
        sm.setCode("T1");
        sm.setID(1889);
        sm.addSlot(ssm);
        cm.addSection(sm);
        
	}
	
	@Test
	public void testLabTuto() {
		assertTrue(Checkboxes.hasLabTuto(c));
		assertFalse(Checkboxes.hasLabTuto(ct));
		st.setCode("LA7");
		ct.addSection(st);
		assertTrue(Checkboxes.hasLabTuto(ct));
	}
	
	@Test
	public void testfulfillbox() {
		
		assertTrue(Checkboxes.hasDay(sec, "Tu"));
		assertFalse(Checkboxes.hasPM(sec));
		assertFalse(Checkboxes.hasDay(sec, "Mo"));
		assertFalse(Checkboxes.hasDay(sec, "We"));
		assertFalse(Checkboxes.hasDay(sec, "Th"));
		assertFalse(Checkboxes.hasDay(sec, "Fr"));
		assertFalse(Checkboxes.hasDay(sec, "Sa"));
		assertTrue(Checkboxes.hasAM(sec));
		Slot slott = new Slot();
		Section sect = new Section();
		slott.setDay(0);
		slott.setStart("12:00PM");
		slott.setEnd("01:00PM");
		sect.addSlot(slott);
		ct.addSection(sect);
		assertTrue(Checkboxes.hasPM(sect));
		assertTrue(Checkboxes.hasDay(sect, "Mo"));
		assertFalse(Checkboxes.hasAM(sm));
	}
	
	@Test
	public void testhasNoExclusion() {
		assertFalse(Checkboxes.hasNoExclusion(c));
		ct.setExclusion("null");
		assertTrue(Checkboxes.hasNoExclusion(ct));
	}
	
	@Test
	public void testhasCCC() {
		assertFalse(Checkboxes.hasCCC(c));
		ct.setAttribute("3Y");
		assertFalse(Checkboxes.hasCCC(ct));
		ct.setAttribute("for 4Y programs");
		assertTrue(Checkboxes.hasCCC(ct));
	}
}