package comp3111.coursescraper;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import comp3111.coursescraper.Controller.enrolledCourseItem;

public class Sfqtest {
	@Test
	public void testSearch() {
		List<enrolledCourseItem> enrolledCources = new ArrayList<>();
		String compare = "";
		task6Functions.search("http://sfq.ust.hk/results/eng-f19.html ",true);
		String str = task6Functions.searchEnrollCourse(enrolledCources);
		assertEquals(compare,str);
	}
	@Test
	public void testSearchInstructor() {
		List<String> instructor = new ArrayList<>();
		String compare = "";
		task6Functions.search("http://sfq.ust.hk/results/eng-f19.html",true);
		
		String str = task6Functions.searchInstructors(instructor);
		assertEquals(compare,str);
	}
	
}
