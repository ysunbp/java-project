package comp3111.coursescraper;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class SectionTest {

    Section sec;
    Slot Wed = new Slot();
    Instructor Cindy = new Instructor("Li, Xin");
    Instructor Albert = new Instructor("CHUNG, Albert Chi Shing");

    @Before
    public void setUp() throws Exception {
        sec = new Section();
        sec.setCode("LA3");
        sec.setID(1831);

        Wed.setStart("09:00AM");
        Wed.setEnd("10:50AM");
        Wed.setDay(2);
        sec.addSlot(Wed);
    }

    @Test
    public void testClone() {
        assertNotEquals(sec, sec.clone());
        assertEquals(sec.toString(), sec.clone().toString());

        sec.addInstructor(Cindy);
        sec.addInstructor(Albert);
        assertNotEquals(sec, sec.clone());
        assertEquals(sec.toString(), sec.clone().toString());
    }

    @Test
    public void testID() {
        assertEquals(1831, sec.getID());
    }

    @Test
    public void testCode() {
        assertEquals("LA3", sec.getCode());
    }

    @Test
    public void testSlot() {
        assertEquals(Wed.toString(), sec.getSlot(0).toString());
        assertEquals(null, sec.getSlot(20));
        assertEquals(null, sec.getSlot(-1));

        assertEquals(1, sec.getNumSlots());

        for (int i = 0; i < 5; i++) {
            sec.addSlot(Wed);
        }
        assertEquals(3, sec.getNumSlots());
    }

    @Test
    public void testInstructor() {
        sec.addInstructor(Cindy);
        sec.addInstructor(Albert);
        
        assertEquals(Cindy.toString(), sec.getAllInstructors()[0].toString());
        assertEquals(Albert.toString(), sec.getAllInstructors()[1].toString());

        assertEquals(2, sec.getNumInstructors());

        for (int i = 0; i < 20; i++) {
            sec.addInstructor(Cindy);
        }
        assertEquals(10, sec.getNumInstructors());
    }

    @Test
    public void testFindInstructorByName(){
        sec.addInstructor(Cindy);
        sec.addInstructor(Albert);
        
        assertEquals(Cindy.toString(), sec.findInstructorByName(Cindy.toString()).toString());
        assertEquals(null, sec.findInstructorByName("Desmond"));
    }
}