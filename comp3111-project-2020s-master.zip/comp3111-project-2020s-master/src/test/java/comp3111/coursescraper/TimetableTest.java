package comp3111.coursescraper;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.List;
import java.util.ArrayList;

import javafx.scene.paint.Color;

public class TimetableTest extends Timetable {

    @Test
    public void testRandomColors() {
        randomColors(100000);
        assertEquals(100000, colors.size());

        List<Color> c = new ArrayList<Color>();
        boolean duplicate = false;
        for (int i = 0; i < colors.size(); i++) {
            if (!c.contains(colors.get(i))) {
                c.add(colors.get(i));
            } else {
                duplicate = true;
            }
        }
        assertEquals(false, duplicate);
    }
}