package comp3111.coursescraper;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.Comparator;

public class BackendTest extends Backend {

    private static Scraper scraper = new Scraper();
    private String url = "https://w5.ab.ust.hk/wcq/cgi-bin";
    private String term = "1910";
    private String subject = "SCIE";

    @Before
    public void setUp() {
        if (scrappedCourses != null) {
            scrappedCourses.clear();
        }

        scrapCourses(url, term, subject);
        if (scrappedCourses == null) {
            System.err.println("404 page not found >.<\n" + "Please check the internet!\n");
        }
    }

    @Test
    public void testScrapCourses() {
        for (int i = 0; i < scrappedCourses.size(); i++) {
            try {
                assertEquals(scraper.scrape(url, term, subject).get(i).toString(), scrappedCourses.get(i).toString());
            } catch (Exception e) {
                System.err.println(e);
                System.err.println("The internet is not stable!\nPlease check the internet!\n");
            }
        }
    }

    @Test
    public void testShowCourses() {
        assertEquals("404 page not found >.<\n" + "Please check the internet or the input.\n", showCourses(null));

        if (scrappedCourses != null) {
            showCourses(scrappedCourses);
            assertEquals(6, NUMBER_OF_COURSES);
            assertEquals(10, NUMBER_OF_SECTIONS);
        }
    }

    @Test
    public void testShowInfo() {
        assertEquals("", showInfo(null));

        scrapCourses(url, term, "COMP");
        if (scrappedCourses != null) {
            showInfo(scrappedCourses);
            assertEquals(false, INSTRUCTOR_NAME.isEmpty());

            List<String> names = INSTRUCTOR_NAME;
            names.sort(Comparator.comparing(String::toString));
            for (int i = 0; i < names.size(); i++) {
                assertEquals(names.get(i), INSTRUCTOR_NAME.get(i));
            }
        }
    }

    @Test
    public void testScrapCourseCode() {
        List<String> code = scraper.scrapeCode(url, term, subject);
        List<String> backendCode = scrapCoursesCode(url, term, subject);
        if (code != null && backendCode != null) {
            for (int i = 0; i < code.size(); i++) {
                assertEquals(code.get(i), backendCode.get(i));
            }
        } else {
			System.err.println("The internet is not stable!\nPlease check the internet!\n");
        }
    }

    @Test
    public void testGetAllInstructors() {
        assertTrue(getAllInstructorNames(scrappedCourses).equals(getAllInstructors()));
    }
}