/**
 * 
 * You might want to uncomment the following code to learn testFX. Sorry, no tutorial session on this.
 * 
 */
package comp3111.coursescraper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import comp3111.coursescraper.Controller.Task3Item;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class FxTest extends ApplicationTest {

	Scraper scraper = new Scraper();

	private Scene s;
	Controller controller;

	@Override
	public void start(Stage stage) throws Exception {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/ui.fxml"));
		VBox root = (VBox) loader.load();
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Course Scraper");
		stage.show();
		s = scene;
		controller = loader.getController();
	}

	@Test
	public void testSelectAll() {
		clickOn("#tabFilter");
		clickOn("#all");
		Button b = (Button) s.lookup("#all");
		CheckBox c1 = (CheckBox) s.lookup("#ambox");
		CheckBox c2 = (CheckBox) s.lookup("#pmbox");
		CheckBox c3 = (CheckBox) s.lookup("#monbox");
		CheckBox c4 = (CheckBox) s.lookup("#tuebox");
		CheckBox c5 = (CheckBox) s.lookup("#wedbox");
		CheckBox c6 = (CheckBox) s.lookup("#Thubox");
		CheckBox c7 = (CheckBox) s.lookup("#Fribox");
		CheckBox c8 = (CheckBox) s.lookup("#Satbox");
		CheckBox c9 = (CheckBox) s.lookup("#cccbox");
		CheckBox c10 = (CheckBox) s.lookup("#ambox");
		CheckBox c11 = (CheckBox) s.lookup("#noexbox");
		CheckBox c12 = (CheckBox) s.lookup("#labtutobox");

		assertTrue(c1.isSelected());
		assertTrue(c2.isSelected());
		assertTrue(c3.isSelected());
		assertTrue(c4.isSelected());
		assertTrue(c5.isSelected());
		assertTrue(c6.isSelected());
		assertTrue(c7.isSelected());
		assertTrue(c8.isSelected());
		assertTrue(c9.isSelected());
		assertTrue(c10.isSelected());
		assertTrue(c11.isSelected());
		assertTrue(c12.isSelected());
		assertEquals(b.getText(), "De-select All");

		clickOn("#all");
		assertFalse(c1.isSelected());
		assertFalse(c2.isSelected());
		assertFalse(c3.isSelected());
		assertFalse(c4.isSelected());
		assertFalse(c5.isSelected());
		assertFalse(c6.isSelected());
		assertFalse(c7.isSelected());
		assertFalse(c8.isSelected());
		assertFalse(c9.isSelected());
		assertFalse(c10.isSelected());
		assertFalse(c11.isSelected());
		assertFalse(c12.isSelected());
		assertEquals(b.getText(), "Select All");
	}
	
	@Test
	public void testfilter() {
		clickOn("#tabFilter");
		clickOn("#ambox");
		clickOn("#pmbox");
		clickOn("#ambox");
		clickOn("#pmbox");
		clickOn("#monbox");
		clickOn("#tuebox");
		clickOn("#monbox");
		clickOn("#tuebox");
		clickOn("#wedbox");
		clickOn("#Thubox");
		clickOn("#wedbox");
		clickOn("#Thubox");
		clickOn("#Fribox");
		clickOn("#Satbox");
		clickOn("#Fribox");
		clickOn("#Satbox");
		clickOn("#cccbox");
		clickOn("#noexbox");
		clickOn("#labtutobox");
		clickOn("#cccbox");
		clickOn("#labtutobox");
		clickOn("#noexbox");
		clickOn("#all");
		clickOn("#all");
		
	}

	@Test
	public void testButtonSearch() {
		clickOn("#tabMain");
		TextField subject = (TextField) s.lookup("#textfieldSubject");
		TextArea console = (TextArea) s.lookup("#textAreaConsole");

		String backend = "";
		Backend.scrappedCourses = null;

		subject.setText("COSC");
		clickOn("#buttonSearch");
		sleep(1000);

		backend = Backend.showCourses(null) + "\n" + Backend.showInfo(null);
		assertTrue(console.getText().equals(backend));

		subject.setText("SCIE");
		clickOn("#buttonSearch");
		sleep(1000);

		if (Backend.scrappedCourses != null && !console.getText().equals(backend)) {
			if (Backend.scrappedCourses.size() != 0) {
				backend = Backend.showCourses(Backend.scrappedCourses) + "\n"
						+ Backend.showInfo(Backend.scrappedCourses);
				assertTrue(console.getText().equals(backend));
			}
		} else {
			System.err.println("The internet is not stable!\nPlease check the internet!\n");
		}
	}

	@Test
	public void testTimetable() {
		TabPane tp = (TabPane) s.lookup("TabPane");
		Tab tabTimetable = (Tab) tp.getTabs().get(4);
		AnchorPane ttAP = (AnchorPane) tabTimetable.getContent();
		AnchorPane slots = (AnchorPane) ttAP.getChildren().get(0);

		clickOn("#tabTimetable");
		assertTrue(slots.getChildren().isEmpty());

		int numSlot = 0;
		Course c = new Course();

		clickOn("#tabMain");
		TextField subject = (TextField) s.lookup("#textfieldSubject");
		TextArea console = (TextArea) s.lookup("#textAreaConsole");
		subject.setText("OCES");
		clickOn("#buttonSearch");
		sleep(3000);

		String backend = Backend.showCourses(null) + "\n" + Backend.showInfo(null);
		if (!console.getText().equals(backend) && Backend.scrappedCourses != null) {
			for (int i = 0; i < Backend.scrappedCourses.size(); i++) {

				c = Backend.scrappedCourses.get(i);
				int count = c.getNumSections();
				String title = c.getTitle();
				title = title.substring(title.indexOf("-") + 1);
				String CourseName = new String(title.substring(0, title.length() - 10));

				for (int j = 0; j < count; j++) {
					Section sec = c.getSection(j);
					String Instruc = "";
					for (int m = 0; m < sec.getNumInstructors(); m++) {
						Instruc += sec.getAllInstructors()[m] + "\n";
					}

					Task3Item item = new Task3Item(sec.getID(), c.getCode() + " " + sec.getCode(), CourseName, Instruc,
							true, c, sec);

					controller.ClickEvent(item);
					numSlot += sec.getNumSlots();
				}
			}
		} else {
			System.err.println("The internet is not stable!\nPlease check the internet!\n");
			c.setTitle("COMP 2711H - Honors Design and Analysis of Algorithms");
			
			
			Section sec1 = new Section();
			Section sec2 = new Section();
			Slot slot = new Slot();
			Instructor ins = new Instructor("Arya");

			slot.setDay(1);
			slot.setStart("09:00AM");
			slot.setEnd("10:30AM");
			slot.setVenue("TBA");

			sec1.addInstructor(ins);
			sec1.addSlot(slot);
			sec1.setCode("L1");
			sec1.setID(1889);

			sec2.addInstructor(ins);
			sec2.addSlot(slot);
			sec2.setCode("L2");
			sec2.setID(1890);

			c.addSection(sec1);
			c.addSection(sec2);

			String title = c.getTitle();
			title = title.substring(title.indexOf("-") + 1);
			String CourseName = new String(title.substring(0, title.length() - 10));

			for (int j = 0; j < c.getNumSections(); j++) {
				Section sec = c.getSection(j);
				String Instruc = "";
				for (int m = 0; m < sec.getNumInstructors(); m++) {
					Instruc += sec.getAllInstructors()[m] + "\n";
				}

				Task3Item item = new Task3Item(sec.getID(), c.getCode() + " " + sec.getCode(), CourseName, Instruc,
						true, c, sec);

				controller.ClickEvent(item);
				numSlot += sec.getNumSlots();
			}
		}
		clickOn("#tabTimetable");
		sleep(1000);

		assertEquals(numSlot, slots.getChildren().size());
		clickOn("#tabStatistic");
	}

	@Test
	public void testButtonInstructorSfq() {
		clickOn("#tabSfq");
		clickOn("#buttonInstructorSfq");
		Button b = (Button) s.lookup("#buttonInstructorSfq");
		sleep(1000);
		assertTrue(b.isDisabled());
	}

	@Test
	public void testAllSubjectSearch() {
		clickOn("#tabMain");
		TextField url = (TextField) s.lookup("#textfieldURL");
		TextField subject = (TextField) s.lookup("#textfieldSubject");
		List<String> CoursesCode = new ArrayList<String>();
		clickOn("#tabAllSubject");
		clickOn("#allsubsearch");
		TextArea console = (TextArea) s.lookup("#textAreaConsole");
		CoursesCode = Backend.scrapCoursesCode("hhhhh", "1910", subject.getText());
		assertFalse(console.getText().equals(null));
		CoursesCode = Backend.scrapCoursesCode(url.getText(), "1910", subject.getText());
		assertFalse(console.getText().equals(null));
		if (CoursesCode != null) {
			assertEquals(CoursesCode.size(), 75);
		}
		clickOn("#allsubsearch");
		assertFalse(console.getText().equals(null));

	}
}
