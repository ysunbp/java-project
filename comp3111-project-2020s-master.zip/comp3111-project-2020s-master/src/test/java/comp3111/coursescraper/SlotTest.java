package comp3111.coursescraper;

import static org.junit.Assert.*;

import java.time.Duration;
import java.time.LocalTime;
import java.util.Locale;
import java.time.format.DateTimeFormatter;

import org.junit.Before;
import org.junit.Test;

public class SlotTest {

    Slot s = new Slot();

    String start = "12:10PM";
    LocalTime startTime = LocalTime.parse(start, DateTimeFormatter.ofPattern("hh:mma", Locale.US));

    String end = "01:20PM";
    LocalTime endTime = LocalTime.parse(end, DateTimeFormatter.ofPattern("hh:mma", Locale.US));


    @Before
    public void setUp() throws Exception {
        s.setDay(1);
        s.setStart(start);
        s.setEnd(end);
        s.setVenue("TBA");
    }

    @Test
    public void testClone() {
        assertNotEquals(s, s.clone());
        assertEquals(s.toString(), s.clone().toString());
    }

    @Test
    public void testStartTime() {
        assertEquals(12, s.getStartHour());
        assertEquals(10, s.getStartMinute());
        assertEquals(startTime, s.getStart());
    }

    @Test
    public void testEndTime() {
        assertEquals(13, s.getEndHour());
        assertEquals(20, s.getEndMinute());
        assertEquals(endTime, s.getEnd());
    }

    @Test
    public void testDuration() {
        assertEquals(Duration.between(startTime, endTime).toMinutes(), s.getLastMinute());
    }

    @Test
    public void testDay() {
        assertEquals(1, s.getDay());
    }

    @Test
    public void testVenue() {
        assertEquals("TBA", s.getVenue());
    }

    @Test
    public void testAtSpecificTime() {
        assertTrue(s.atSpecificTime(Slot.DAYS[1], 12, 10));
        assertTrue(s.atSpecificTime(Slot.DAYS[1], 13, 20));

        assertEquals(false, s.atSpecificTime(Slot.DAYS[5], 13, 00));

        assertEquals(false, s.atSpecificTime(Slot.DAYS[1], 13, 40));
        assertEquals(false, s.atSpecificTime(Slot.DAYS[1], 15, 10));

        assertEquals(false, s.atSpecificTime(Slot.DAYS[1], 11, 40));
        assertEquals(false, s.atSpecificTime(Slot.DAYS[1], 12, 00));        
    }
}