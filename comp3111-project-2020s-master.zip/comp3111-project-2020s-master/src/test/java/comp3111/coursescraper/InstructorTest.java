package comp3111.coursescraper;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class InstructorTest {
    Instructor goodGuy;

    @Before
    public void setUp() throws Exception {
        goodGuy = new Instructor("Desmond");
    }

    @Test
    public void instructorToString() {
        assertEquals("Desmond", goodGuy.toString());
    }

    @Test
    public void testClone() {
        assertNotEquals(goodGuy, goodGuy.clone());
        assertEquals(goodGuy.toString(), goodGuy.clone().toString());
    }

    @Test
    public void testName() {
        goodGuy.setName("TSOI, Yau Chat");
        assertEquals("TSOI, Yau Chat", goodGuy.getName());
    }
}