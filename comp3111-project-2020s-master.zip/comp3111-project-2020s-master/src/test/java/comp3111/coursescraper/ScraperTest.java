package comp3111.coursescraper;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.gargoylesoftware.htmlunit.WebClient;

public class ScraperTest {
	WebClient client = new WebClient();
	String url = "https://w5.ab.ust.hk/wcq/cgi-bin/";
	String hh = "abc";
	String term = "1910";
	String sub = "COMP";
	Scraper s = new Scraper();

	@Before
	public void setUp() throws Exception {
		client.getOptions().setCssEnabled(false);
		client.getOptions().setJavaScriptEnabled(false);
	}

	@Test
	public void testscrape() {
		try {
			assertNotNull(s.scrape(url, term, sub));
		} catch (Exception e) {
			System.err.println(e);
		}

		Boolean thrown = false;
		try {
			assertEquals(s.scrape(hh, term, sub), null);
		} catch (Exception e) {
			thrown = true;
		}
		assertTrue(thrown);
	}

	@Test
	public void testscrapeCode() {
		List<String> code = s.scrapeCode(url, term, sub);
		if (code != null) {
			assertEquals(code.size(), 75);
		}
		assertEquals(s.scrapeCode(hh, term, sub), null);

	}
}