package comp3111.coursescraper;

import org.junit.Test;
import org.junit.Before;

import static org.junit.Assert.*;

public class CourseTest {
    Course c = new Course();
    String description = "Discrete mathematics needed for the study of computer science";
    String Exclusion = "COMP 2711, MATH 2343";

    Section sec = new Section();
    Section sec2 = new Section();

    Slot slot = new Slot();
    Instructor ins = new Instructor("Arya");
    Instructor ins2 = new Instructor("name");

    @Before
    public void setUp() throws Exception {
        c.setTitle("COMP 2711H - Honors Design and Analysis of Algorithms");
        c.setDescription(description);
        c.setExclusion(Exclusion);
        c.setAttribute("attribute");

        slot.setDay(1);
        slot.setStart("09:00AM");
        slot.setEnd("10:30AM");
        slot.setVenue("TBA");

        sec.addInstructor(ins);
        sec.addInstructor(ins2);
        sec.addSlot(slot);
        sec.setCode("L1");
        sec.setID(1889);

        sec2.addInstructor(ins);
        sec2.addSlot(slot);
        sec2.setCode("L1");
        sec2.setID(1889);
    }

    @Test
    public void testClone() {
        assertNotEquals(c, c.clone());
        assertEquals(c.toString(), c.clone().toString());

        c.addSection(sec);
        assertNotEquals(c, c.clone());
        assertEquals(c.toString(), c.clone().toString());
    }

    @Test
    public void testCloneWithSection() {
        c.addSection(sec);
        assertNotEquals(c, c.cloneWithoutSection());
        assertEquals(c.getCode(), c.cloneWithoutSection().getCode());
        assertEquals(c.getTitle(), c.cloneWithoutSection().getTitle());
        assertEquals(c.getDescription(), c.cloneWithoutSection().getDescription());
        assertEquals(c.getExclusion(), c.cloneWithoutSection().getExclusion());
        assertEquals(c.getAttribute(), c.cloneWithoutSection().getAttribute());
        assertNotEquals(c.getNumSections(), c.cloneWithoutSection().getNumSections());
    }

    @Test
    public void testCode() {
        assertEquals("COMP2711H", c.getCode());
    }

    @Test
    public void testTitle() {
        assertEquals(c.getTitle(), "COMP 2711H - Honors Design and Analysis of Algorithms");

        c.setTitle("title");
        assertEquals(c.getTitle(), "title");
    }

    @Test
    public void testDescription() {
        assertEquals(c.getDescription(), description);
    }

    @Test
    public void testExclusion() {
        assertEquals(c.getExclusion(), Exclusion);
    }

    @Test
    public void testAttribute() {
        assertEquals("attribute", c.getAttribute());
    }

    @Test
    public void testSection() {
        c.addSection(null);
        c.addSection(sec);
        assertEquals(sec.toString(), c.getSection(0).toString());
        assertEquals(null, c.getSection(1));
        assertEquals(null, c.getSection(-1));

        assertEquals(sec.toString(), c.getSectionByCode(sec.getCode()).toString());
        assertEquals(null, c.getSectionByCode("R1"));

        assertEquals(sec.toString(), c.getSectionByID(sec.getID()).toString());
        assertEquals(null, c.getSectionByID(1234));

        for (int i = 0; i < 120; i++) {
            c.addSection(sec);
        }
        assertEquals(100, c.getNumSections());
    }

    @Test
    public void testInstructor() {
        c.addSection(sec);
        c.addSection(sec2);
        assertEquals(2, c.getNumInstructors());

        for (int i = 0; i < sec.getNumInstructors(); i++) {
            assertEquals(sec.getAllInstructors()[i].toString(), c.getAllInstructors()[i].toString());
        }
    }

    @Test
    public void testSlot() {
        sec.addSlot(slot);
        c.addSection(sec);
        c.addSection(sec2);

        assertEquals(sec.getNumSlots() + sec2.getNumSlots(), c.getNumSlots());

        for (int i = 0; i < sec.getNumSlots(); i++) {
            assertEquals(sec.getSlot(i).toString(), c.getSlot(i).toString());
        }
        for (int i = 0; i < sec2.getNumSlots(); i++) {
            assertEquals(sec2.getSlot(i).toString(), c.getSlot(sec.getNumSlots() + i).toString());
        }

        assertEquals(null, c.getSlot(-1));
        assertNotEquals(null, c.getSlot(c.getNumSlots() - 1));
        assertEquals(null, c.getSlot(c.getNumSlots()));
    }
}