
# deCOVID Team T-06

> https://github.com/PearlLHF/comp3111-project-2020s.git

---
## Team Members

### LYU, Hanfang

> email: hlyuag | github: PearlLHF | dev branch: [pearl_dev](https://github.com/PearlLHF/comp3111-project-2020s/tree/pearl_dev)

> [Task 1 & Task 4](./activities/sampleIO/Task1+Task4-SampleIO-LYU_Hanfang.pdf)

### SUN, Yushi

> email: ysunbp | github: ysunbp | dev branch: ys_task2, ys_task5 & [ys_dev](https://github.com/PearlLHF/comp3111-project-2020s/tree/ys_dev)

> [Task 2 & Task 5](./activities/sampleIO/Task2%2B5_SampleIO_SUN%20Yushi.pdf)

### ZENG, Junyan

> email: jzengag | github: jzengag | dev branch: [jzengag_dev](https://github.com/PearlLHF/comp3111-project-2020s/tree/jzengag_dev)

> [Task 3 & Task 6](./activities/sampleIO/task3&#32;and&#32;task6&#32;sampleIO.pdf)

---
## [Activities](./activities)

### [Activity 1 - System Requirement Specification](./activities/activity-1/Activity-1-Integrated.pdf)

- [Data model diagram](activities/activity-1/Data-Model-Diagram.pdf)
- [Use-case diagram](activities/activity-1/Use-Case-Diagram.pdf)
- [Use-case specification](activities/activity-1/Use-Case-Specification.pdf)

### [Activity 2 - Software Implementation and Testing](./activities/activity-2) 

- [Meeting minutes](./activities/activity-2/meeting-minutes.pdf)
- [Gantt chart](./activities/activity-2/gantt-chart.pdf)
- [Burn down chart](./activities/activity-2/burn-down-chart.pdf)

### [Sample Input and Output (Screenshots)](./activities/sampleIO)

- [Task 1 & Task 4](./activities/sampleIO/Task1+Task4-SampleIO-LYU_Hanfang.pdf)
- [Task 2 & Task 5](./activities/sampleIO/Task2%2B5_SampleIO_SUN%20Yushi.pdf)
- [Task 3 & Task 6](./activities/sampleIO/task3&#32;and&#32;task6&#32;sampleIO.pdf)

### [Test Reports](./activities/reports%20screenshot)

- [Test report](./activities/reports%20screenshot/pic1.png)
- [Jacoco test report](./activities/reports%20screenshot/pic2.png)
